# OneGov AI — Setup Guide

> End-to-end setup for the **OneGov AI — Smart Citizen Assistant** demo.
> Fictional/whitelabeled content. Target region: **AWS me-central-1 (UAE)**.
> Part of the MENAT Industry AI Accelerator (UseCase Repo V3).

## 0. Prerequisites
- AWS account with Bedrock access in me-central-1 and an available Nova / Bedrock
  foundation model + an embeddings model.
- Python 3.12, Node 18+ (for the CDK outline), AWS CLI configured.
- Bedrock Guardrails available in-region.

## 1. Explore the package
```
PublicSectorCitizenAIDemo/
├── sample_data/        fictional citizens, licences, benefits, utilities, visa, health
│   └── policy_docs/    markdown policy docs for the RAG knowledge base
├── agent/              agent_instructions.md + action_groups/*.yaml (OpenAPI 3.0)
├── guardrails/         guardrail_config.json
├── backend/            lambda_handlers.py (working mock action-group handlers)
├── infra/              deploy_notes.md (CDK/TypeScript outline)
└── SETUP_GUIDE.md      this file
```

## 2. Try the backend locally (no AWS needed)
```bash
cd PublicSectorCitizenAIDemo/backend
python lambda_handlers.py
```
You'll see all five action groups respond, including the two signature behaviours:
licence renewal **blocked** by outstanding fines, and benefits eligibility **grounded**
in policy. Every state change prints an `AUDIT` line with the citizen ID masked.

## 3. Build the knowledge base (RAG)
1. Create an **OpenSearch Serverless** vector collection (or an **S3 Vectors** bucket)
   in me-central-1 — Bedrock Knowledge Bases are not yet in-region.
2. Chunk `sample_data/policy_docs/*.md`, embed with an in-region Bedrock embeddings
   model, and index into the collection.
3. Expose retrieval to the agent (custom retrieval action group, or KB association
   when available in-region).

## 4. Create the Guardrail
Create a Bedrock Guardrail from `guardrails/guardrail_config.json` (console or
`CreateGuardrail`). It enforces PII anonymisation, denied topics (medical / legal /
financial advice, out-of-scope), and content filters. Note the guardrail id + version.

## 5. Deploy the data + Lambda
1. Create the DynamoDB tables (see `infra/deploy_notes.md`) and seed them from
   `sample_data/*.json`.
2. Deploy `backend/lambda_handlers.py` as the action-group Lambda. For production,
   switch the JSON reads to DynamoDB and enable the `audit_log` writes.

## 6. Create the Bedrock Agent
1. New Bedrock Agent; paste `agent/agent_instructions.md` as the instruction.
2. Attach the Guardrail from step 4.
3. Add **five action groups**, each using the matching OpenAPI schema in
   `agent/action_groups/` and pointing at the Lambda from step 5.
4. Associate the knowledge base from step 3.
5. Prepare + create an alias.

## 7. Wire the front end
API Gateway + Cognito in front of the agent; CloudFront/S3 for the demo UI (voice via
Transcribe/Polly, document upload via Textract). All in me-central-1.

## 8. Run the demo
Follow `../Demo_Script.md` (in the parent folder) — five citizen journeys plus the
live Guardrails moment. Suggested demo citizen: **Amina Al-Rashid** (`MED-1990-004471`).

## Demo cheat-sheet (fictional data)
| Journey | Try | Expect |
|---|---|---|
| Licence renewal | Amina renews `DL-MED-55012` | Success + reference number |
| Blocked renewal | Omar renews `DL-MED-55013` | Blocked — outstanding fines |
| Benefits | Amina eligibility | Housing + Family Supplement, cited |
| Benefits (none) | Omar eligibility | Not eligible — income too high |
| Utility dispute | Amina disputes `BILL-2026-09-200145` | Ticket number |
| Residency | Layla status (`RES-2026-33110`) | Awaiting documents + next step |
| Health | Book `CLN-CAP-01` / `S-1014-0900` | Confirmation id |
| Guardrail | "What medication for chest pain?" | Refused — directed to care |

---
*Maintained by Mahmoud Elserafi · MENAT Industry AI Accelerator · fictional demo content only.*
