"""
OneGov AI — mock action-group Lambda handlers (demo).

Working mock implementations backing the five Bedrock Agent action groups. Each
handler reads the fictional JSON in ../sample_data and returns a response shaped
for Bedrock Agents.

Bedrock Agent invocation contract (simplified):
  event = {
    "actionGroup": "...",
    "apiPath": "/licenses/renew",
    "httpMethod": "POST",
    "parameters": [{"name": "citizen_id", "value": "..."}],   # for GET query params
    "requestBody": {"content": {"application/json": {"properties": [
        {"name": "license_id", "value": "..."} ]}}}            # for POST bodies
  }
Return shape:
  {"response": {"actionGroup", "apiPath", "httpMethod",
                "httpStatusCode", "responseBody": {"application/json": {"body": "<json str>"}}}}

In production, replace the JSON file reads with DynamoDB calls and write every
state change to the audit log. Everything here is in-region (me-central-1).
"""

import json
import os
import uuid
from datetime import datetime, timezone

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "sample_data")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _load(name):
    with open(os.path.join(DATA_DIR, name), "r", encoding="utf-8") as fh:
        return json.load(fh)


def _params(event):
    """Flatten GET query params and POST body properties into one dict."""
    out = {}
    for p in event.get("parameters", []) or []:
        out[p["name"]] = p["value"]
    try:
        props = event["requestBody"]["content"]["application/json"]["properties"]
        for p in props:
            out[p["name"]] = p["value"]
    except (KeyError, TypeError):
        pass
    return out


def _respond(event, status, body):
    return {
        "response": {
            "actionGroup": event.get("actionGroup"),
            "apiPath": event.get("apiPath"),
            "httpMethod": event.get("httpMethod"),
            "httpStatusCode": status,
            "responseBody": {"application/json": {"body": json.dumps(body, ensure_ascii=False)}},
        }
    }


def _audit(action, citizen_id, detail):
    """Stub audit write — in production, put_item to the audit DynamoDB table + CloudTrail."""
    record = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "action": action,
        "citizen_id_masked": (citizen_id[:7] + "***") if citizen_id else None,
        "detail": detail,
    }
    print("AUDIT", json.dumps(record, ensure_ascii=False))
    return record


# --------------------------------------------------------------------------- #
# 1. Licences & permits
# --------------------------------------------------------------------------- #
def handle_licenses(event):
    p = _params(event)
    api = event.get("apiPath", "")
    data = _load("licenses.json")["licenses"]

    if api == "/licenses/status":
        recs = [l for l in data if l["citizen_id"] == p.get("citizen_id")]
        return _respond(event, 200, {"licenses": recs})

    if api == "/licenses/renew":
        rec = next((l for l in data if l["license_id"] == p.get("license_id")
                    and l["citizen_id"] == p.get("citizen_id")), None)
        if not rec:
            return _respond(event, 404, {"success": False, "message": "Licence not found."})
        if not rec["eligible_for_renewal"]:
            return _respond(event, 200, {
                "success": False,
                "blocked_reason": rec.get("renewal_block_reason", "Not eligible for renewal."),
                "message": "Renewal is blocked. " + rec.get("renewal_block_reason", ""),
            })
        ref = "RNW-" + uuid.uuid4().hex[:8].upper()
        _audit("license_renew", p.get("citizen_id"), {"license_id": rec["license_id"], "ref": ref})
        return _respond(event, 200, {
            "success": True,
            "reference_number": ref,
            "message": f"Licence {rec['license_id']} renewed. Fee MED {rec['renewal_fee_med']}. Ref {ref}.",
        })

    return _respond(event, 400, {"message": "Unknown licences path."})


# --------------------------------------------------------------------------- #
# 2. Benefits eligibility
# --------------------------------------------------------------------------- #
def handle_benefits(event):
    p = _params(event)
    b = _load("benefits.json")
    programs = b["programs"]
    case = next((c for c in b["citizen_cases"] if c["citizen_id"] == p.get("citizen_id")), None)
    if not case:
        return _respond(event, 404, {"message": "No benefits case found for this citizen."})

    eligible, not_eligible = [], []
    for prog in programs:
        e = prog["eligibility"]
        reasons = []
        if "max_household_income_med" in e and case["household_income_med"] > e["max_household_income_med"]:
            reasons.append(f"Household income exceeds MED {e['max_household_income_med']}.")
        if "residency_years_min" in e and case["residency_years"] < e["residency_years_min"]:
            reasons.append(f"Requires {e['residency_years_min']} years residency.")
        if "dependents_min" in e and case["dependents"] < e["dependents_min"]:
            reasons.append(f"Requires at least {e['dependents_min']} dependents.")
        if e.get("registered_jobseeker") and not case.get("registered_jobseeker"):
            reasons.append("Must be a registered jobseeker.")
        if reasons:
            not_eligible.append({"program_id": prog["program_id"], "reason": " ".join(reasons),
                                 "policy_ref": prog["policy_ref"]})
        else:
            eligible.append({"program_id": prog["program_id"], "name_en": prog["name_en"],
                             "monthly_amount_med": prog["monthly_amount_med"],
                             "policy_ref": prog["policy_ref"]})
    _audit("benefit_eligibility_check", p.get("citizen_id"), {"eligible": [x["program_id"] for x in eligible]})
    return _respond(event, 200, {"eligible": eligible, "not_eligible": not_eligible})


# --------------------------------------------------------------------------- #
# 3. Utilities & complaints
# --------------------------------------------------------------------------- #
def handle_utilities(event):
    p = _params(event)
    api = event.get("apiPath", "")
    data = _load("utilities.json")

    if api == "/utilities/bill":
        acct = next((a for a in data["accounts"] if a["citizen_id"] == p.get("citizen_id")), None)
        if not acct:
            return _respond(event, 404, {"message": "No utility account found."})
        return _respond(event, 200, acct)

    if api == "/utilities/complaint":
        if p.get("category") not in data["complaint_categories"]:
            return _respond(event, 400, {"success": False, "message": "Unknown complaint category."})
        ticket = "TKT-" + uuid.uuid4().hex[:8].upper()
        _audit("utility_complaint", p.get("citizen_id"),
               {"category": p.get("category"), "ticket": ticket})
        return _respond(event, 200, {
            "success": True, "ticket_id": ticket,
            "message": f"Complaint filed under '{p.get('category')}'. Ticket {ticket}.",
        })

    return _respond(event, 400, {"message": "Unknown utilities path."})


# --------------------------------------------------------------------------- #
# 4. Visa / residency
# --------------------------------------------------------------------------- #
def handle_residency(event):
    p = _params(event)
    apps = _load("visa_residency.json")["applications"]
    rec = next((a for a in apps if a["citizen_id"] == p.get("citizen_id")), None)
    if not rec:
        return _respond(event, 404, {"message": "No residency application found."})
    _audit("residency_status_check", p.get("citizen_id"), {"application_id": rec["application_id"]})
    return _respond(event, 200, {
        "application_id": rec["application_id"],
        "status": rec["status"],
        "current_stage": rec["current_stage"],
        "missing_documents": rec["missing_documents"],
        "next_step": rec["next_step"],
        "policy_ref": rec["policy_ref"],
    })


# --------------------------------------------------------------------------- #
# 5. Health appointments
# --------------------------------------------------------------------------- #
def handle_health(event):
    p = _params(event)
    api = event.get("apiPath", "")
    data = _load("health.json")

    if api == "/health/clinics":
        clinics = data["clinics"]
        if p.get("region"):
            clinics = [c for c in clinics if c["region"].lower() == p["region"].lower()]
        if p.get("service"):
            clinics = [c for c in clinics if p["service"] in c["services"]]
        return _respond(event, 200, {"clinics": clinics})

    if api == "/health/book":
        clinic = next((c for c in data["clinics"] if c["clinic_id"] == p.get("clinic_id")), None)
        if not clinic:
            return _respond(event, 404, {"success": False, "message": "Clinic not found."})
        slot = next((s for s in clinic["available_slots"] if s["slot_id"] == p.get("slot_id")), None)
        if not slot:
            return _respond(event, 409, {"success": False, "message": "Slot no longer available."})
        conf = "APT-" + uuid.uuid4().hex[:8].upper()
        _audit("health_booking", p.get("citizen_id"),
               {"clinic": clinic["clinic_id"], "slot": slot["slot_id"], "conf": conf})
        return _respond(event, 200, {
            "success": True, "confirmation_id": conf,
            "message": f"Booked at {clinic['name_en']} on {slot['date']} {slot['time']}. Ref {conf}.",
        })

    return _respond(event, 400, {"message": "Unknown health path."})


# --------------------------------------------------------------------------- #
# Router — one Lambda, or split into five (one per action group)
# --------------------------------------------------------------------------- #
ROUTES = {
    "licenses": handle_licenses,
    "benefits": handle_benefits,
    "utilities": handle_utilities,
    "residency": handle_residency,
    "health": handle_health,
}


def lambda_handler(event, context=None):
    """Entry point. Routes on apiPath prefix, so a single Lambda can back all groups."""
    api = event.get("apiPath", "")
    key = api.strip("/").split("/")[0] if api else ""
    handler = ROUTES.get(key)
    if not handler:
        return _respond(event, 400, {"message": f"No handler for path '{api}'."})
    return handler(event)


# --------------------------------------------------------------------------- #
# Local smoke test:  python lambda_handlers.py
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    tests = [
        {"apiPath": "/licenses/status", "httpMethod": "GET",
         "parameters": [{"name": "citizen_id", "value": "MED-1990-004471"}]},
        {"apiPath": "/licenses/renew", "httpMethod": "POST",
         "parameters": [{"name": "citizen_id", "value": "MED-1990-004471"}],
         "requestBody": {"content": {"application/json": {"properties": [
             {"name": "license_id", "value": "DL-MED-55012"}]}}}},
        {"apiPath": "/licenses/renew", "httpMethod": "POST",
         "parameters": [{"name": "citizen_id", "value": "MED-1985-002310"}],
         "requestBody": {"content": {"application/json": {"properties": [
             {"name": "license_id", "value": "DL-MED-55013"}]}}}},
        {"apiPath": "/benefits/eligibility", "httpMethod": "GET",
         "parameters": [{"name": "citizen_id", "value": "MED-1990-004471"}]},
        {"apiPath": "/utilities/complaint", "httpMethod": "POST",
         "parameters": [{"name": "citizen_id", "value": "MED-1990-004471"}],
         "requestBody": {"content": {"application/json": {"properties": [
             {"name": "category", "value": "billing_dispute"},
             {"name": "bill_id", "value": "BILL-2026-09-200145"},
             {"name": "disputed_amount_med", "value": 180}]}}}},
        {"apiPath": "/residency/status", "httpMethod": "GET",
         "parameters": [{"name": "citizen_id", "value": "MED-1998-008890"}]},
        {"apiPath": "/health/book", "httpMethod": "POST",
         "parameters": [{"name": "citizen_id", "value": "MED-1990-004471"}],
         "requestBody": {"content": {"application/json": {"properties": [
             {"name": "clinic_id", "value": "CLN-CAP-01"},
             {"name": "slot_id", "value": "S-1014-0900"}]}}}},
    ]
    for t in tests:
        out = lambda_handler(t)
        body = out["response"]["responseBody"]["application/json"]["body"]
        print(f"\n{t['apiPath']} -> {out['response']['httpStatusCode']}\n  {body}")
