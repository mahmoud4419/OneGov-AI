# OneGov AI — Deployment Notes (AWS CDK / TypeScript outline)

> Region: **me-central-1 (UAE)** throughout. Whitelabeled demo. Illustrative — adapt
> to your account's guardrail/model availability.

## Stacks

```
OneGovAiApp (CDK App)
├── DataStack          — DynamoDB tables + S3 buckets, seeded from sample_data/
├── KnowledgeStack     — S3 Vectors / OpenSearch Serverless collection for policy RAG
├── AgentStack         — Bedrock Agent, action groups, Guardrail, IAM
└── FrontendStack      — API Gateway + Cognito + CloudFront/S3 (demo UI)
```

### Why S3 Vectors / OpenSearch (not Bedrock Knowledge Bases)
Bedrock Knowledge Bases are **not available in me-central-1**. Build the RAG vector
store on **S3 Vectors** or **Amazon OpenSearch Serverless** in-region, generate
embeddings with an in-region Bedrock embeddings model, and wire retrieval into the
agent as a custom retrieval action (or via the agent's KB association once available).

## DataStack (sketch)
```ts
const citizens = new dynamodb.Table(this, 'Citizens', {
  partitionKey: { name: 'citizen_id', type: dynamodb.AttributeType.STRING },
  billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
  removalPolicy: RemovalPolicy.DESTROY,          // demo only
});
// repeat for licenses, benefits, utilities, visa_residency, health, audit_log
// seed with a custom resource / init Lambda that loads sample_data/*.json
```

## KnowledgeStack (sketch)
```ts
// Option A: OpenSearch Serverless vector collection
const coll = new opensearchserverless.CfnCollection(this, 'PolicyVectors', {
  name: 'onegov-policy', type: 'VECTORSEARCH',
});
// Ingest sample_data/policy_docs/*.md: chunk -> embed (Bedrock) -> index.
// Option B: S3 Vectors bucket (if preferred) — same ingest pipeline, S3 Vectors sink.
```

## AgentStack (sketch)
```ts
const guardrail = new bedrock.CfnGuardrail(this, 'OneGovGuardrail',
  require('../../guardrails/guardrail_config.json'));   // map fields to CfnGuardrail props

const fn = new lambda.Function(this, 'ActionGroupFn', {
  runtime: lambda.Runtime.PYTHON_3_12,
  handler: 'lambda_handlers.lambda_handler',
  code: lambda.Code.fromAsset('../backend'),
  environment: { DATA_SOURCE: 'dynamodb' },             // flip off the JSON mocks in prod
});

const agent = new bedrock.CfnAgent(this, 'OneGovAgent', {
  agentName: 'onegov-ai',
  foundationModel: '<in-region Nova/Bedrock model id>',
  instruction: readFileSync('../agent/agent_instructions.md', 'utf8'),
  guardrailConfiguration: { guardrailIdentifier: guardrail.attrGuardrailId },
  actionGroups: [
    // one per OpenAPI schema in agent/action_groups/*.yaml, all pointing at fn
    { actionGroupName: 'licenses',  apiSchema: { payload: readFileSync('../agent/action_groups/licenses.yaml','utf8') },
      actionGroupExecutor: { lambda: fn.functionArn } },
    // benefits, utilities, visa_residency, health ...
  ],
});
```

## IAM (least privilege)
- Action-group Lambda: read/write only its own domain tables + `put_item` on `audit_log`.
- Agent role: `bedrock:InvokeModel` on the chosen model; `bedrock:ApplyGuardrail`.
- Knowledge ingest role: read `policy_docs` bucket, write the vector collection.

## Credentials note (Isengard)
Isengard session tokens expire ~1h. For a multi-stack `cdk deploy`, use
`aws-vault exec <profile> -- npx cdk deploy --all --require-approval never`, or deploy
stack-by-stack so each completes within the token lifetime.

## Deploy
```bash
npm install
npx cdk bootstrap aws://<account>/me-central-1
npx cdk deploy --all --require-approval never
```
