# Licensing & Permits Policy — Republic of Medina (FICTIONAL)

> Fictional policy content for the OneGov AI demo knowledge base. Not real legislation.

## 1. Scope
Covers driving licences and trade/business permits issued to citizens and residents.

## 2. Driving licence renewal
2.1 A light-vehicle driving licence is valid for 5 years.
2.2 Renewal may be initiated up to 90 days before expiry and up to 1 year after
expiry without re-testing.
2.3 **Renewal is blocked while traffic fines remain outstanding.** All fines must
be settled before a renewal can be processed.
2.4 Standard renewal fee: MED 300.

## 3. Trade / business permit renewal
3.1 Home-business trade permits are valid for 2 years.
3.2 Standard renewal fee: MED 500.
3.3 Renewal requires an up-to-date registered address.

## 4. Eligibility checks performed at renewal
- Identity verification of the citizen.
- Outstanding-fine check (driving licences).
- Address validity (trade permits).

## 5. Processing
Renewals requested through OneGov AI are completed in real time once eligibility
checks pass, and a reference number is issued. Every action is logged.
