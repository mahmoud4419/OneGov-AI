# Residency & Visa Policy — Republic of Medina (FICTIONAL)

> Fictional policy content for the OneGov AI demo knowledge base. Not real legislation.

## 1. Application types
- Residency renewal
- Family sponsorship
- Employment residency

## 2. Processing stages
2.1 Every application moves through: submitted → document review → security check
→ approval → issued.
2.2 Security checks typically take 5–7 working days.

## 3. Family sponsorship
3.1 A citizen or resident may sponsor immediate family members.
3.4 **Required documents:** attested marriage certificate (spouse), birth
certificates (children), and proof of income for the last 3 months.

## 4. Document handling
4.1 Documents may be uploaded via OneGov AI (photo capture supported) or at a
service centre.
4.2 Applicants are told exactly which documents remain outstanding and what each
next step is.

## 5. Status transparency
Applicants may ask OneGov AI for their current status at any time; the response
states the current stage, any missing documents, and the next action.
