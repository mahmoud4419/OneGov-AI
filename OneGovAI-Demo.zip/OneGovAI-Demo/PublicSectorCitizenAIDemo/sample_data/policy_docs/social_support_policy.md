# Social Support Policy — Republic of Medina (FICTIONAL)

> Fictional policy content for the OneGov AI demo knowledge base. Not real legislation.

## 1. Purpose
This policy defines the social-support programmes available to citizens of the
Republic of Medina and the eligibility criteria for each.

## 2. General principles
2.1 Support is means-tested against verified household income.
2.2 Applicants must be citizens unless a programme explicitly states otherwise.
2.3 Each citizen may hold at most one income-replacement benefit at a time, but
may combine an income-replacement benefit with the Housing Support Allowance.

## 3. Definitions
3.1 **Household income** — the combined gross monthly income of all adults at the
registered address, expressed in Medina Dirham (MED).
3.2 **Dependent** — a child under 18, or an adult family member with a recognised
care need, registered to the applicant.

## 4. Housing Support Allowance
4.1 Provides a monthly contribution toward rent or mortgage costs.
4.2 **Eligibility:** household income at or below MED 15,000/month; at least 3
years of continuous residency; citizen applicant.
4.3 Amount: MED 2,500/month. Reviewed annually.

## 5. Family Income Supplement
5.1 **Eligibility:** household income at or below MED 10,000/month; at least 2
registered dependents; citizen applicant.
5.2 Amount: MED 1,800/month.

## 6. Jobseeker Support
6.1 Supports citizens actively seeking employment.
6.3 **Eligibility:** household income at or below MED 8,000/month; registered as
an active jobseeker; citizen applicant.
6.4 Amount: MED 1,200/month, for up to 12 months.

## 7. How to apply
Applications may be made through OneGov AI, the citizen portal, or any service
centre. Decisions are grounded in this policy and are fully auditable.
