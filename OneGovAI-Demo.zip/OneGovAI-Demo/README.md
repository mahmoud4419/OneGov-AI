# OneGov AI — the Smart Citizen Assistant

**An agentic, multimodal, bilingual (Arabic / English) government citizen-services assistant, built on AWS AI.**

> *"A chatbot answers. OneGov AI gets it done."*

OneGov AI is a Public Sector demo for the MENAT Industry AI Accelerator. It shows an
AI assistant that doesn't just answer FAQs — it **completes government transactions**
end-to-end: renewing licences, checking benefit eligibility, filing municipal
complaints, tracking residency applications, and booking health appointments — in
Arabic or English, by voice or text, with government-grade safety, auditability, and
in-region data residency.

> ⚠️ **Whitelabel notice.** This repository uses a fictional national digital-government
> platform ("OneGov") and a fictional country ("the Republic of Medina"). All citizens,
> accounts, policies, and data are invented. No real government, customer, or country
> is referenced. Safe for public sharing.

---

## What's in this repo

| Path | What it is |
|---|---|
| `README.md` (this file) | Overview + index |
| `OneGov_AI_Pitch.pptx` | 13-slide executive pitch deck (Amazon-branded) |
| `architecture-diagram.png` | Reference architecture diagram |
| `docs/README.md` | Full demo brief (pitch, AWS services, scenarios, positioning) |
| `docs/ARCHITECTURE.md` | Reference architecture + UAE data-residency notes |
| `docs/Demo_Script.md` | ~15-min presenter runbook, 5 citizen journeys |
| `PublicSectorCitizenAIDemo/` | **Phase 2 — the buildable package** (below) |

### Phase 2 — buildable package
```
PublicSectorCitizenAIDemo/
├── SETUP_GUIDE.md              end-to-end setup + demo cheat-sheet
├── sample_data/                fictional citizens, licences, benefits, utilities, visa, health
│   └── policy_docs/            markdown policy docs for the RAG knowledge base
├── agent/
│   ├── agent_instructions.md   Bedrock Agent system prompt
│   └── action_groups/*.yaml    5 OpenAPI 3.0 action-group schemas
├── guardrails/guardrail_config.json   PII, denied topics, content filters
├── backend/lambda_handlers.py  working mock action-group handlers (all 5 groups)
└── infra/deploy_notes.md       AWS CDK (TypeScript) deployment outline
```

## The AWS AI stack
Bedrock Agents / AgentCore · Amazon Nova · Transcribe · Polly · Textract ·
Bedrock Guardrails · S3 Vectors / OpenSearch (in-region RAG).

## Five citizen journeys
1. Licence renewal by voice · 2. Benefits eligibility (cited) · 3. Utility complaint
from a photo · 4. Visa / residency status + next steps · 5. Health appointment booking
— plus a live **Guardrails** moment (refuses medical advice, redacts PII).

## Built for the UAE
Architected for **AWS me-central-1**. Because Bedrock Knowledge Bases aren't yet in
me-central-1, the RAG vector store runs on **S3 Vectors / OpenSearch** — called out
explicitly to stay technically honest for Public Sector buyers.

## Quick start
```bash
cd PublicSectorCitizenAIDemo/backend
python lambda_handlers.py     # runs all five action groups against the sample data
```
Then follow `PublicSectorCitizenAIDemo/SETUP_GUIDE.md` to stand it up on AWS.

---
*Part of the MENAT Industry AI Accelerator (UseCase Repo V3). Maintained by Mahmoud Elserafi. Fictional/whitelabeled demo content only.*
